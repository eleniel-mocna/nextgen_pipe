#include "IncludeDefine.h"
#include "Parameters.h"
#include "Transcript.h"

bool extendAlign( char* R, char* G, uint rStart, uint gStart, int dR, int dG, uint L, uint Lprev, uint nMMprev, uint nMMmax, double pMMmax, bool extendToEnd, Transcript* trA );

