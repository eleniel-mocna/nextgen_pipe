#ifndef BLOCKS_OVERLAP_DEF
#define BLOCKS_OVERLAP_DEF

#include "IncludeDefine.h"
#include "Transcript.h"

uint blocksOverlap(Transcript &t1, Transcript &t2);


#endif
